// Quarry options controller.
"use strict";

const api = typeof browser !== "undefined" ? browser : chrome;
const $ = (id) => document.getElementById(id);

function setStatus(text, isErr = false) {
  const el = $("saveStatus");
  el.textContent = text;
  el.className = isErr ? "save-status err" : "save-status";
  if (text) setTimeout(() => { el.textContent = ""; }, 2500);
}

function applyTheme(themeName) {
  let effectiveTheme = themeName;
  if (themeName === "system") {
    effectiveTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  document.documentElement.setAttribute("data-theme", effectiveTheme);
}

async function checkHealth() {
  const badge = $("statusBadge");
  const text = $("statusText");
  const port = parseInt($("port").value, 10) || 8765;

  text.textContent = "Connecting...";

  try {
    const res = await fetch(`http://127.0.0.1:${port}/health`, {
      signal: AbortSignal.timeout ? AbortSignal.timeout(3000) : undefined,
    });
    const data = await res.json();
    if (data.ok) {
      badge.className = "status-badge online";
      text.textContent = `Online (v${data.version})`;
      if (!$("destDir").value && data.downloadDir) {
        $("destHint").textContent = `Default: ${data.downloadDir}`;
      }
      return;
    }
    throw new Error("Invalid response");
  } catch {
    badge.className = "status-badge offline";
    text.textContent = "Offline";
  }
}

async function init() {
  const stored = await api.storage.local.get({
    destDir: "",
    port: 8765,
    maxImages: 0,
    theme: "light",
    alwaysShowCarousel: true,
  });

  $("destDir").value = stored.destDir || "";
  $("port").value = stored.port || 8765;
  $("maxImages").value = stored.maxImages || 0;
  if ($("alwaysShowCarousel")) $("alwaysShowCarousel").checked = stored.alwaysShowCarousel !== false;
  if ($("themeSelect")) $("themeSelect").value = stored.theme || "light";

  applyTheme(stored.theme || "light");
  await checkHealth();
}

async function save(e) {
  if (e) e.preventDefault();

  const newPort = parseInt($("port").value, 10);
  const destDir = $("destDir").value.trim();
  const maxImages = parseInt($("maxImages").value, 10) || 0;
  const alwaysShowCarousel = $("alwaysShowCarousel") ? $("alwaysShowCarousel").checked : true;
  const theme = $("themeSelect") ? $("themeSelect").value : "light";

  if (!newPort || newPort < 1 || newPort > 65535) {
    setStatus("Port must be 1-65535", true);
    return;
  }

  if (destDir && !/^[a-zA-Z]:[\\/]/.test(destDir) && !destDir.startsWith("\\\\") && !destDir.startsWith("/")) {
    setStatus("Enter a valid full path", true);
    return;
  }

  await api.storage.local.set({
    destDir,
    port: newPort,
    maxImages,
    alwaysShowCarousel,
    theme,
  });

  applyTheme(theme);
  setStatus("Saved");
  checkHealth();
}

async function reset() {
  await api.storage.local.remove(["destDir", "port", "maxImages", "alwaysShowCarousel", "theme"]);
  await init();
  setStatus("Defaults restored");
}

$("settingsForm").addEventListener("submit", save);
$("resetBtn").addEventListener("click", reset);
$("port").addEventListener("change", checkHealth);
if ($("themeSelect")) $("themeSelect").addEventListener("change", (e) => applyTheme(e.target.value));

init();
